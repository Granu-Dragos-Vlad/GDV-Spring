package com.springboot.proiect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProiectApplicationTests {

	@Test
	void contextLoads() {
	}

}
